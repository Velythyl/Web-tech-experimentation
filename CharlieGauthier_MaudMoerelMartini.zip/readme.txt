Equipe:
	Nom: Charlie Gauthier, matricule: 20105623
	Nom: Maud Moerel-Martini, matricule: 20037754

Lien vers le site publique au DIRO:
	http://www-ens.iro.umontreal.ca/~gautchar/IFT3225/TP3/rapport.xhtml

La source des PHP n'est pas accesible directement par mesure de bonnes pratiques/sécurité. Les fichiers sont donc placés
dans des ZIP. Si vous voulez que je prouve que le contenu des zip, de la remise, et du serveur sont identiques,
simplement nous le demander :)
